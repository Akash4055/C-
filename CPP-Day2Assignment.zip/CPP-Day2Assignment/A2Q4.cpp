//#include<iostream>
//using namespace std;
//class myclass
//{
//private : int num;
//public: 
//	myclass()
//	{
//		this-> num=0;
//		cout<<"i am default";
//	}
//	myclass(int num)
//	{
//		this->num=num;
//	}
//	~myclass()
//	{
//		cout<<"i am destructor";
//	}
//};
//int main()
//{
//	myclass * ptr;
//	cout<<"WELCOME USER"<<"\n"<<"HOW MANY INSTANCES TO CREATE ?";
//	int no;
//	cin>>no;
//	ptr= new myclass[no];
//	delete ptr;
//}