class myclass
{
	int bookid;
	char *bookname;
	int price;
public:
	myclass(int bookid,char* bookname,int price);
	~myclass();
	int getbookid();
	char * getbookname();
	int getprice();
	myclass(myclass &ref);
};