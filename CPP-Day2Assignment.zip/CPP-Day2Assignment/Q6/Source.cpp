#include<iostream>
#include "D:\c-prog interview book\CPP practice\A2Q_client\A2Q6.h";
using namespace std;
int main()
{
	myclass m1(1,"let us c",200);
	myclass *m=new myclass(2,"mysql",300);
	cout<<m1.getbookname();
	cout<<(*m).getbookid();
	cout<<m1.getprice();
}
