//#include<iostream>
//using namespace std;
// class myclass
// {
//private:
//	int num;
//
// public :
//	 myclass()
//	 {
//		 cout<<"i am constructor"<<"\n";
//	 }
//	 ~myclass()
//	 {
//		 cout<<"i am thanos/corona"<<"\n";
//	 }
//	 myclass(int a)
//	 {
//		 cout<<"i am param"<<"\n"; 
//		 num=a;
//	 }
//	 int getnum()
//	 {
//		 return num;
//	 }
//	 void setnum(int a)
//	 {
//		 num=a;
//	 }
// };
// int main()
// {
//	 
//	  myclass m1;
//	  myclass m2(100);
//	 m1.setnum(5);
//	 myclass arr[5];
//	 for(int i=0;i<5;i++)
//	 {
//		 int num;
//		 cout<<"insert values for \t"<<i<<"\n";
//		 cin>>num;
//		 arr[i].setnum(num);
//	 }
//	 for(int i=0;i<5;i++)
//	 {
//		 cout<<"\n"<<arr[i].getnum();
//	 }
//	  myclass * ptr ; 
//	 ptr = new myclass [3];
//	 
//	 for(int i=0;i<3;i++)
//	 {
//		 int num;
//		 cout<<"insert values for \t"<<i<<"\n";
//		 cin>>num;
//		 ptr[i].setnum(num);
//	 }
//	 for(int i=0;i<3;i++)
//	 {
//		 cout<<"\n"<<ptr[i].getnum();
//	 }
//	  delete [] ptr;
// 
// }