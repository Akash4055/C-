//#include<iostream>
//using namespace std;
//class myclass
//{
//private: int num;
//public:
//	myclass()
//	{
//		cout<<"i am default";
//	}
//	myclass( int num)
//	{
//		this->num=num;
//		cout<<"i am param";
//	}
//	~myclass()
//	{
//		cout<<"i am destructor";
//	}
//	void disp()
//	{
//		cout<< num;
//	}
//};
//class myclass1
//{
//private: int num1;
//public:
//	myclass1()
//	{
//		cout<<"i am default of myclass1";
//	}
//	myclass1(int num1)
//	{
//		this->num1=num1;
//		cout<<"i am param of myclass1";
//	}
//	void disp1(myclass &ref)
//	{
//		ref.disp();
//	}
//};
//int main()
//{
//	myclass m1(100);
//	myclass1 m2(50);
//	m2.disp1(m1);
//}