//#include<iostream>
//using namespace std;
//class myclass
//{
//private: int num;
//		static int counter;
//public:
//	myclass()
//	{
//		cout<<"i am constructor";
//		num=0;
//		counter++;
//	}
//	myclass(int num)
//	{
//		this->num=num;
//		counter++;
//	}
//	myclass(myclass &ref)
//	{
//		this->num=ref.num;
//		counter++;
//	}
//	~myclass()
//	{
//		counter--;
//	}
//	static int getcounter()
//	{
//		return counter;
//	}
//}; 
//int myclass ::counter=0;
//int main()
//{
//	myclass m1;
//	myclass m2(100);
//	myclass m3=m1;
//	myclass * ptr=new myclass;
//	delete ptr;
//	cout<<m1.getcounter();
//}