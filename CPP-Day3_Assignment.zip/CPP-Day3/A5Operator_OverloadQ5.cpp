//#include<iostream>
//using namespace std;
//class myclass
//{
//private : int num;
//public:
//	myclass(int num)
//	{
//		this->num=num;
//	}
//	void disp1()
//	{
//		cout<<"i am inside Disp1"<<endl<<num<<endl;
//	}
//	void disp2()
//	{
//		cout<<"i am inside Disp2 calling disp1()"<<endl;
//		disp1();
//	}
//};
//int main()
//{
//	myclass m(50);
//	myclass &ref=m;
//	ref.disp2();
//}