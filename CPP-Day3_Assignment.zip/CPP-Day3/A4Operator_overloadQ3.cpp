//#include<iostream>
//using namespace std;
//class Module2;
//class Module1
//{
//	int duration;
//	public:
//		Module1(int k)
//		{
//			duration=k;
//		}
//		friend void check(Module1 &, Module2 &);
//};
//class Module2
//{
//		int duration;
// 	public:
//		Module2(int k)
//		{
//			duration=k;
//		}
//		friend void check(Module1 &, Module2 &);
//};
//void check(Module1 & M1, Module2 & M2)
//{
//	if(M1.duration==M2.duration)
//		cout<<"Same"<<endl;
//	else
//		cout<<"Not Same"<<endl;
//}
//int main()
//{
//	Module1 Dac(90);
//	Module2 DBDA(80);
//	check(Dac,DBDA);
//}