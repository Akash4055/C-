//#include<iostream>
//using namespace std;
//class Second;
//class First
//   {
//	   char str1[20];
//   public : void setstr(char* str1)
//			{
//				strcpy(this->str1,str1);
//			}
//			friend void concatstr(First &, Second &b);
//   };
//   class Second
//   {
//      char str2[20];
//	     public : void setstr(char* str2)
//			{
//				strcpy(this->str2,str2);
//			}
//	friend void concatstr(First &, Second &b);
//   };
//   void concatstr(First & a,Second & b)
//   {
//	   char str3[40];
//	   strcpy(str3,a.str1);
//	   strcat(str3,b.str2);
//	   cout<<str3<<endl;
//   }
//
//   int main()  
//{
//	First f;
//	f.setstr("Akash");
//	Second s;
//	s.setstr("Dhawale");
//	concatstr(f,s);
// }