//#include<iostream>
//using namespace std;
//class Second;
//class First
//{
//	int a;
//public:
//	void seta( int a)
//	{
//		this->a=a;
//	}
//	friend class Second;
//};
//class Second
//{
//	public:
//		void fun1(First &ref)
//		{
//			cout<<ref.a<<endl;
//		}
//		void fun2(First &ref1)
//		{
//			cout<<ref1.a<<endl;
//		}
//		void fun3(First &ref2)
//		{
//			cout<<ref2.a<<endl;
//		}
//};
//int main()
//{
//	First f;
//	f.seta(5);
//	Second s;
//	s.fun1(f);
//	s.fun2(f);
//	s.fun3(f);
//}