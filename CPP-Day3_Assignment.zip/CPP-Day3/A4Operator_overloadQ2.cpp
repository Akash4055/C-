//#include<iostream>
//using namespace std;
//class sample
//   {
//	private:
//		char ch;
//	public:
//		sample(char ch)
//		{
//			this->ch=ch;
//		}
//		friend void display(sample &);
//  };
//void display(sample & ref)
//{
//	cout<<ref.ch<<endl;
//}
//int main()
//{
//	sample s('a');
//	display(s);
//}