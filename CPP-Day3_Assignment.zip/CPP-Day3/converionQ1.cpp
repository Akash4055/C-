//#include<iostream>
//using namespace std;
//class Minute;
//class Hour
//{
//	private:
//		int hr;
//	public:
//		Hour(int hr)
//		{
//			this->hr=hr;
//		}
//		void disp()
//		{
//			cout<<hr<<endl;
//		}
//		void operator=(Minute &);
//};
//class Minute
//{
//	private:
//		int mnt;
//	public:
//		Minute(int mnt)
//		{
//			this->mnt=mnt;
//		}
//		void disp()
//		{
//			cout<<mnt<<endl;
//		}
//		friend void Hour:: operator=(Minute&);
//};
//void Hour:: operator=(Minute& ref)
//{
//	this->hr=(ref.mnt)/60;
//}
//int main()
//{
//	Hour h(1);
//	Minute m(60);
//	h.disp();
//	m.disp();
//	Minute m2(120);
//	h=m2;
//	h.disp();
//}